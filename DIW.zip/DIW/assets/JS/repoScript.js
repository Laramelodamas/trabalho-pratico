document.addEventListener("DOMContentLoaded", function() {
    const urlParams = new URLSearchParams(window.location.search);
    const repoName = urlParams.get('repo');

    if (!repoName) {
        console.error('Repository name not provided.');
        return;
    }

    fetch(`https://api.github.com/repos/Laramelodamas/${repoName}`)
        .then(response => response.json())
        .then(repo => {
            document.getElementById('repo-name').textContent = repo.name;
            document.getElementById('repo-description').textContent = repo.description || 'No description available';
            document.getElementById('repo-stars').textContent = repo.stargazers_count;
            document.getElementById('repo-forks').textContent = repo.forks_count;
        })
        .catch(error => console.error('Error fetching repo details:', error));
});
