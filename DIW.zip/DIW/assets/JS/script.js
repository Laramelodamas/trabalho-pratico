document.addEventListener("DOMContentLoaded", function() {
    const repoList = document.getElementById('repo-list');

    function fetchRepos() {
        fetch('assets/json/repos.json') // Carrega o JSON local
            .then(response => response.json())
            .then(repos => {
                repoList.innerHTML = ''; // Limpa a lista de repositórios antes de recriá-la
                repos.forEach(repo => {
                    const repoCard = document.createElement('div');
                    repoCard.classList.add('col', 'mb-4'); // Adiciona classes Bootstrap para espaçamento
                    repoCard.innerHTML = `
                        <div class="card h-100">
                            <div class="card-body">
                                <h5 class="card-title">${repo.name}</h5>
                                <p class="card-text">${repo.description || 'No description available'}</p>
                                <div class="d-flex justify-content-between align-items-center mt-auto">
                                    <div class="d-flex align-items-center">
                                        <i class="fa-solid fa-star text-secondary"></i>
                                        <p class="m-0 ms-1">${repo.stargazers_count}</p>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <i class="fa-solid fa-code-fork text-primary"></i>
                                        <p class="m-0 ms-1">${repo.forks_count}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                    repoList.appendChild(repoCard);
                });
            })
            .catch(error => console.error('Error fetching repos:', error));
    }

    // Chama a função fetchRepos ao carregar a página inicialmente
    fetchRepos();

    // Opcional: Implementar um botão ou funcionalidade para recarregar os repositórios manualmente
    // Exemplo: Um botão "Atualizar Repositórios" que chama fetchRepos()

    // Exemplo de implementação de um botão para atualizar os repositórios manualmente
    const updateButton = document.getElementById('update-repos-button');
    if (updateButton) {
        updateButton.addEventListener('click', function() {
            fetchRepos();
        });
    }
});


document.addEventListener("DOMContentLoaded", function () {
    const repoList = document.getElementById("repo-list");
    const username = "Laramelodamas"; // Substitua pelo seu nome de usuário do GitHub

    fetch(`https://api.github.com/users/${username}/repos`)
        .then(response => response.json())
        .then(data => {
            data.forEach(repo => {
                const repoDiv = document.createElement("div");
                repoDiv.classList.add("col");

                repoDiv.innerHTML = `
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title">${repo.name}</h5>
                            <p class="card-text">${repo.description || "Sem descrição"}</p>
                            <a href="${repo.html_url}" class="btn btn-primary" target="_blank">Ver repositório</a>
                        </div>
                    </div>
                `;
                repoList.appendChild(repoDiv);
            });
        })
        .catch(error => console.error('Erro ao carregar repositórios:', error));
});
